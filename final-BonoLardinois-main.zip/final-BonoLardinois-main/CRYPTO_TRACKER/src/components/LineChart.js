import React, { useEffect, useState } from 'react';
import Axios from 'axios'
import { Line } from 'react-chartjs-2';

const LineChart = ({info, days}) => {
    const coingecko = 'https://api.coingecko.com/api/v3/coins/'
    const [coindata, setCoindata] = useState([])

    // function to convert the data into the right format
    const convertData = data => {
        return data.map(el => {
            return {
                x: Intl.DateTimeFormat('en-US', {year: 'numeric', month: '2-digit',day: '2-digit', hour: '2-digit', minute: '2-digit', second: '2-digit'}).format(el[0]) ,
                y: el[1]
            }
        })
    }

    // api call to get historic data
    useEffect (() => {
        const fetchdata = async () => {
            const response = await Axios.get(coingecko + info + '/market_chart' , {
                params: {
                    vs_currency: "eur",
                    days: days
                }
            })
            setCoindata(convertData(response.data.prices))            
        }
        fetchdata()
    }, [])

    // data for the chart
    const data = {
        datasets: [
          {
            label: 'Price',
            data: coindata,
            fill: false,
            backgroundColor: "rgba(174, 305, 194, 0.5)",
            borderColor: "rgba(174, 305, 194, 0.4",
            pointRadius: 0,
            fill: true
          },
        ],
      };
      
      // chart configurations
      const options = {
        scales: {
          yAxes: [{ ticks: {beginAtZero: true},
              },],
          xAxes: [{ type: "time",
              distribution: "lineair"
              }],
        },
      };
      
      return (
        <>
        <div className='header'>
          <h1 className='title'>Line Chart</h1>
        </div>
        <Line data={data} options={options} />
      </>
      )
}

export default LineChart;
