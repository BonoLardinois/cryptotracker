import React, { useState, useEffect } from 'react';
import Coin_details from './Coin_details';
import Axios from 'axios';

const Coins_render = () => {
    const [watchlist, setWatchlist] = useState( localStorage.getItem('watchlist').split(",") ||
        ["bitcoin", "ethereum", "ripple", "dogecoin"])

    const [data, setData] = useState([])

    // making api call to get data on all the coins
    useEffect (() => {
        const data_coins = async () => {
            const response = await Axios.get("https://api.coingecko.com/api/v3/coins/markets", {
                params:{
                    vs_currency: "eur",
                }
            })
            setData(response.data)
        }
        data_coins()
    }, [])

    // local storage for the user
    useEffect (() => {
       localStorage.setItem('watchlist', watchlist)
    }, [watchlist])
    
    //  coin options to select
    const renderOptions = (data) => {
        return (
            <option key = {data.id} value = {data.id}> {data.name}</option>
        )
    }

    // add coins to watchlist
    const addCoin = (e) => {
        setWatchlist(watchlist.concat(e.target.value))
    }

    // delete coins from watchlist
    const deleteCoin = (e) => {
        alert(e.target.value)
        const newList = watchlist.filter((item) => item !== e.target.value)
        setWatchlist(newList)
    }


    return (
        <div>
            <div className="bg-dark rounded">
                <div className="padding">
                    <div>
                        <select className="btn btn-secondary dropdown-toggle text-dark rounded w-120" default="Add Coins" onChange={addCoin}>
                            <option value="Add Coins">Add Coins</option>
                            {data.map(renderOptions)}
                        </select>
                    </div>
                    <br/>
                    {watchlist.length === 0 &&
                        <h2 className="text-dark">
                            You have no coins yet
                        </h2>
                    }
                    {watchlist.length > 0 &&
                        <div className="accordion">
                            <Coin_details watchlist={watchlist} deleteCoin={deleteCoin}/>
                        </div>
                    }
                    </div>
                </div>  
        </div>
    )
}

export default Coins_render
