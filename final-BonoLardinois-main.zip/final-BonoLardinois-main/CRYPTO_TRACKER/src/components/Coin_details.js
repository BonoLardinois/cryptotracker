import React, { useEffect, useState } from 'react'
import Axios from 'axios'
import {Accordion, Card, Tab, Tabs} from 'react-bootstrap';
import LineChart from './LineChart';


const Coin_details = ({watchlist, deleteCoin}) => {
    const transfrom = Object.values(watchlist)
    const [data, setData] = useState([])
    
    // api call to get coin data
    useEffect (() => {
        const data_coins = async () => {
            const response = await Axios.get("https://api.coingecko.com/api/v3/coins/markets", {
                params:{
                    vs_currency: "eur",
                    ids: transfrom.join(",")
                }
            })
            setData(response.data)
        }
        data_coins()
    }, [watchlist])

    // render data for each coin in accordion
    const renderAccordion = (data) => {
        let id = data.id
        
        return (
            <Accordion className="border-radius:7px bg-dark" key={data.id}>
            <Card className="AccordionCard">
              <Accordion.Toggle as={Card.Header} eventKey={data.name}
                    className="text-white bg-dark border border-dark">
                        <div className="cointainer">
                            <div className="row">
                                <div className="col-sm">
                                    <img className="photo" src={data.image} alt="" />
                                </div>
                                <div className="col-sm">
                                    {data.name}
                                </div>
                                <div className="col-sm">
                                    €{data.current_price}
                                </div>
                                <div className="col-sm">
                                <span className={data.price_change_percentage_24h < 0? "text-danger" : "text-success"}>
                                    <i className={data.price_change_percentage_24h < 0? "fas fa-long-arrow-alt-down" : "fas fa-long-arrow-alt-up"}></i> 
                                    {data.price_change_percentage_24h.toFixed(2)}%
                                    </span>
                                </div>
                                <div className="col-sm-1"> 
                                    <button className="btn btn-outline-danger delete_icon" onClick={deleteCoin} value={data.id}>
                                        <i className="fas fa-ban"></i>
                                    </button>
                                </div> 
                                <div className="col-sm">
                                    <i class="fas fa-angle-down"></i> 
                                </div>
                            </div>
                        </div>    
              </Accordion.Toggle>
              <Accordion.Collapse eventKey={data.name}>
                <Card.Body className="bg-dark">
                    <span className="text-light h2">Data {data.name}</span>
                    <Tabs defaultActiveKey="year" id="uncontrolled-tab-example" className="align-items-center text-white">
                    <Tab eventKey="1day" title="1 Day">
                        <br/>
                        <LineChart info={data.id} days="1"></LineChart>
                    </Tab>
                    <Tab eventKey="7day" title="7 Days">
                        <br/>
                        <LineChart info={data.id} days="7"></LineChart>
                    </Tab>
                    <Tab eventKey="month" title="Month">
                        <br/>
                        <LineChart info={data.id} days="31"></LineChart>
                    </Tab>
                    <Tab eventKey="year" title="Year">
                        <br/>
                        <LineChart info={data.id} days="365"></LineChart>
                    </Tab>
                    <Tab eventKey="Max" title="Max">
                        <br/>
                        <LineChart info={data.id} days="max"></LineChart>
                    </Tab>
                    </Tabs>
                    <div className="padding">
                        <div className="container text-dark rounded">
                            <div className="row">
                                <div className="col border border-dark bg-secondary rounded">
                                    <div className="h5">Rank </div>
                                    <div className="coin_info">{data.market_cap_rank}</div>
                                </div>
                                <div className="col border border-dark bg-secondary rounded">
                                    <div className="h5">Market Cap </div>
                                    <div className="coin_info">€ {data.market_cap}</div>
                                </div>
                                <div className="col border border-dark bg-secondary rounded">
                                    <div className="h5">Total volume </div>
                                    <div className="coin_info">€ {data.total_volume}</div>
                                </div>
                            </div>
                            <div className="row">
                                <div className="col border border-dark bg-secondary rounded">
                                    <div className="container">
                                        <div className="row">
                                            <div className="h5">24-h High/Low </div>
                                        </div>
                                        <div className="row">
                                            <div className="col h5">High</div>
                                            <div className="coin_info col text-left">€ {data.high_24h}</div>
                                        </div>
                                        <div className="row">
                                            <div className="col h5">Low</div>
                                            <div className="coin_info col text-left">€ {data.low_24h}</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </Card.Body>
              </Accordion.Collapse>
            </Card>
          </Accordion>
        )
    }

    return (
        <div>
            <div>
                <div className="container text-dark bg-secondary text-white">
                    <div className="row">
                        <div className="col-sm"></div>
                        <div className="col-sm">Name</div>
                        <div className="col-sm">Price</div>
                        <div className="col-sm">%-24h</div>
                        <div className="col-sm-1"></div>
                        <div className="col-sm"></div>
                    </div>
                </div>
                {data.map(renderAccordion)} 
            </div>
        </div>

    )
}

export default Coin_details
