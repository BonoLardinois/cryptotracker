import React from 'react'
import './App.css';
import Coins_render from './components/Coins_render';

function App() {

  return (
    <div className="App">
      <div className="App-header">
        <div className="col-md-2"></div>
        <header className="col-md-8">
          <h1 className="text-warning">Coin Tracker</h1>
          <Coins_render/>
       </header>
        <div className="col-md-2"></div>

      </div>
    </div>
  );
}

export default App;
