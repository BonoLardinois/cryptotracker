# Assesment
In this section the code snippets of which I'm the proudest will be discussed. 

- The api call in LineChart: because I made the api call via a variable and altered the endpoints of the api call I can make dynamic api calls depending on which coins are in the users watchlist. 
- The delete function which I struggled with a lot has turnt out good. The user still needs to wait a bit until all the info about the coins is loaded but it is called in the coin details component and then brought back up to coin render component. 
- Converting of the data for the line chart, this took me a long time to understand the format of the data that the graph needed in order to succeed.
- Also because the app is meant for a quick check of the users coins it is a good design should it be implemented on a smaller screen like phone or tablet
- Lastly the logic of the text and arrow which turn red when the course is going down and green when the course is going up, same for the arrow. I know i could have done this with some useState logic but I wanted to challange myself in turning it in html logic. 

