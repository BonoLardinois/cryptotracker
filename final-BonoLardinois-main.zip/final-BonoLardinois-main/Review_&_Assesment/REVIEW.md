# Code Review
In this section the code review will be discussed. the review of my code has been done with two other students: Sarah Danner & Mila Sparreboom. 

## Readable code
In this section I will discuss the comments made on each of my files regarding the readability.

#### Coin_details:   
- It's clear when the api call is being made and when it will be made again, altough I did have to clearify what the params where           
- The rest of the file is only returning the data got via the api call in a html document
- Did get rit of some console.log's

#### Coin_render:
- No questions and commets were clear according to my reviewers
- Did get rit of some console.log's
- Had to explain the html logic with the if statements, for when the watchlist was empty


#### LineChart:
- not questions were asked so I think this was all clear to them 

## Stylistic issues:
- Still had a few console.log's in my code which i took out afther the code review
- The api call to get data about the coins is made twice, once in the Coin_render and once in the coin_details. This is because in the Coin_render the call is made to get all the coins that are available from the api and in the coin_details only the coins which are on the watchlist are called via the api. Im sure there is a better solution for this so the two almost identical api calls aren't both needed but I don't know how this is done unfortunately.
- Comments are a bit scarce so the files could do with some more comments but this is not a big issue. 
- The returns of the components could be smaller. This can be done by putting more of the return in functions and calling these in the return. 
- The delete function only works when the data of the coin is fully loaded which is weird and so this could be designed better. Maybe the delete function button should only render when everything is finished loading, I'm still figuring out how to fix this issue.


## Conclusion
Concluding I can say that the application works well altough there are a few weakspots. For exaple does the delte button only work when a coin is fully done loading and is the application very slow because of the number of api calls it has to make. This can be fixed with some minor adjustments 
